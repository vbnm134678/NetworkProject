package Server;

import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

import com.google.gson.*;

public class LoginServer {

	private static BufferedReader inputStream = null;
	private static PrintWriter outputStream = null;
	private static int user;

	static Gson g = new Gson();

	public static void main(String[] args) throws Exception {
		System.out.println("The chat server is running");
		ExecutorService pool = Executors.newFixedThreadPool(500);
		try (ServerSocket listener = new ServerSocket(50505)) {
			while (true) {
				pool.execute(new Handler(listener.accept()));
			}
		}
	}

	private static class Handler implements Runnable {

		private Socket socket;
		private Scanner in;
		private PrintWriter out;

		public Handler(Socket socket) {
			this.socket = socket;

		}

		public void run() {
			try {

				// 소켓 스트림
				in = new Scanner(socket.getInputStream());
				out = new PrintWriter(socket.getOutputStream(), true);
				String line;
				while (true) {
					try {
						File user = new File("users");
						if (!user.exists())
							user.mkdir();
						
						outputStream = new PrintWriter(new FileWriter(
								"users/user.txt", true));
						outputStream.append(" ".trim());
						
						inputStream = new BufferedReader(new FileReader(
								"users/user.txt"));
					} catch (FileNotFoundException e) {
						System.out.println("There's no file");
					}
					
					// 텍스트파일 한줄씩 읽기
					ArrayList<String> userList = new ArrayList<String>();
					String aline = inputStream.readLine();
					user = 0;
					while(aline != null) {
						user++;
						userList.add(aline);
						aline = inputStream.readLine();
					}
					String[] js = userList.toArray(new String[0]);	

					// 읽은 String을 JsonObject로 변환
					JsonObject[] obj = new JsonObject[user];
					for (int i = 0; i < user; i++) {
						obj[i] = g.fromJson(js[i], JsonObject.class);
					}
					line = in.nextLine();
					if (line.startsWith("LOGIN")) {
						out.println("LOGININFO");
						line = in.nextLine();
						String[] info = line.split(",");
						// info[0]는 id info[1]은 password
						for (int i = 0; i < user; i++) {
							// id, password 둘다 같으면 login성공
							if (info[0].equals(obj[i].get("id").getAsString())
									&& info[1].equals(obj[i].get("password").getAsString())) {
								obj[i].addProperty("condi", "yes");
								out.println("SUCCESS");
								break;
							} else if (info[0].equals(obj[i].get("id").getAsString())
									&& !info[1].equals(obj[i].get("password").getAsString())) {
								out.println("WRONGPASSWORD");
								break;
							} else if (i == user - 1) {
								out.println("WRONGID");
							}
						}
					}
					// 비밀번호 찾기
					else if (line.startsWith("FIND")) {
						out.println("FINDINFO");
						line = in.nextLine();
						String[] info = line.split(",");
						for (int i = 0; i < user; i++) {
							if (info[0].equals(obj[i].get("id").getAsString())
									&& info[1].equals(obj[i].get("address").getAsString()))
								out.println("PW" + obj[i].get("password").getAsString());
						}
					}
					// id중복체크
					else if (line.startsWith("CHECKID")) {
						out.println("ID");
						line = in.nextLine();
						for (int i = 0; i < user; i++) {
							if (line.equals(obj[i].get("id").getAsString())) {
								out.println("SAMEID");
								break;
							} else if (i == user - 1)
								out.println("UNIQUEID");
						}
					}
					// nickname 중복체크
					else if (line.startsWith("CHECKNICK")) {
						out.println("NICK");
						line = in.nextLine();
						for (int i = 0; i < user; i++) {
							if (line.equals(obj[i].get("nickname").getAsString())) {
								out.println("SAMENICK");
								break;
							} else if (i == user - 1)
								out.println("UNIQUENICK");
						}
					}
					// 회원가입
					else if (line.startsWith("SIGN")) {
						out.println("NEWSIGN");
						line = in.nextLine();
						String[] info = line.split(",");
						String newUser = "{\"id\":" + "\"" + info[0] + "\"" + "," + "\"nickname\":" + "\"" + info[1]
								+ "\"" + "," + "\"password\":" + "\"" + info[2] + "\"" + "," + "\"address\":" + "\""
								+ info[3] + "\"" + "," + "\"birth\":" + "\"" + info[4] + "\"" + ","
								+ "\"condi\":\"no\"}";
						outputStream.println(newUser);
						user++;
						outputStream.close();
						inputStream.close();
						
						// 채팅 부분이랑 호환되게 수정 TODO
						JsonObject chatObj = new JsonObject();
						chatObj.addProperty("id", info[0]);
						chatObj.addProperty("name", info[1]);
						chatObj.add("friend", new JsonArray());
						chatObj.add("chat", new JsonArray());
						chatObj.addProperty("state", "");
						String logOutTime = new SimpleDateFormat("yyyy-MM-dd-HH-mm").format(Calendar.getInstance().getTime());
						chatObj.addProperty("last", logOutTime);

						BufferedWriter userListWriter = new BufferedWriter(new FileWriter(
								"users/@UserList.txt", true));
						userListWriter.append(info[0] + "\n");
						userListWriter.close();
						
						File userFolder = new File("users/" + info[0]);
						if (!userFolder.exists())
							userFolder.mkdir();
						
						BufferedWriter userInfoWriter = new BufferedWriter(new FileWriter(
								"users/" + info[0] + "/info.txt", false));
						userInfoWriter.append(chatObj.toString() + "\n");
						userInfoWriter.close();
						
					}
					else if(line.startsWith("THANK")) {
						break;
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}

}
